﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KarelWebAnketAuto.VM_Model
{
    public class VM_ApiDialWithUsername
    {
        public string userName { get; set; }
        public string number { get; set; }
        public string IsCryptedData { get; set; }
        public string ApiDialReturnMessage { get; set; }
        public bool durumType { get; set; }
    }
}
