﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KarelWebAnketAuto.Model
{
    public class ApiDialWithUsername
    {
        public string ApiDialReturnMessage { get; set; }
    }
}
