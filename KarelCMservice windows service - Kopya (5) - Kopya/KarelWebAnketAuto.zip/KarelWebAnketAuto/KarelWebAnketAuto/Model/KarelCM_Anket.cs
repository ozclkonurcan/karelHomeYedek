﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KarelWebAnketAuto.Model
{
    public class KarelCM_Anket
    {
        public string musNumber { get; set; }
    }
}
