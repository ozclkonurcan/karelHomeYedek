﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KarelWebAnketAuto.Model
{
    public class ControlNumberData
    {
        public string Ad { get; set; }
        public string Telefon { get; set; }
        public bool Durum { get; set; }
    }
}
